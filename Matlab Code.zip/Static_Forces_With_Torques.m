syms theta2 theta3 a2 a3 a4 F1 F2 F3 M1 M2 M3

% Define the determinant of the Jacobian matrix
det_J = a3 * a4 * (a4 * sin(theta2) * cos(theta3)^2 + a4 * cos(theta2) * sin(theta3) * cos(theta3) + ...
                   a2 * sin(theta3) - a4 * sin(theta2) + a3 * cos(theta2) * sin(theta3));

% Solve for theta2 and theta3 when the determinant is zero
solutions = solve(det_J == 0, [theta2, theta3], 'Real', true);

% Display the solutions
disp('Solutions for theta2 and theta3 when the determinant is zero:');
disp(solutions);

% Define the Jacobian matrix (J) and forces (F)
J = [ ...
    a4*cos(theta2)*sin(theta3), -a3*sin(theta2), 0;
    -a3*cos(theta2), a4*sin(theta3), 0;
    0, 0, 1];

F = [F1; F2; F3]; % External forces acting on the end-effector

% Calculate the torques (tau) required at the joints
tau = transpose(J) * F;

% Display the torques
disp('Torques at the joints:');
disp(tau);
