syms theta2 theta3 a2 a3 a4

% Define the determinant of the Jacobian matrix
det_J = a3 * a4 * (a4 * sin(theta2) * cos(theta3)^2 + a4 * cos(theta2) * sin(theta3) * cos(theta3) + ...
                   a2 * sin(theta3) - a4 * sin(theta2) + a3 * cos(theta2) * sin(theta3));

% Solve for theta2 and theta3 when the determinant is zero
solutions = solve(det_J == 0, [theta2, theta3], 'Real', true);

% Display the solutions
disp('Solutions for theta2 and theta3 when the determinant is zero:');
disp(solutions);
