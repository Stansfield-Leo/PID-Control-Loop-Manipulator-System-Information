% MATLAB code to generate position, velocity, and acceleration values for multiple waypoints
% The generated trajectory uses a cubic polynomial for each segment, and the script plots position, velocity,
% and acceleration curves on the same chart for visualization.

% Clear workspace and close all figures
clear; clc; close all;

% Create a UI figure for inputs and plot
hFig = uifigure('Name', 'Via Point Path Trajectory Planner', 'Position', [100, 100, 600, 800]);

% Create a UI axis for plotting
ax = uiaxes('Parent', hFig, 'Position', [20, 20, 550, 300]);

% Create input fields for boundary conditions
lbl1 = uilabel(hFig, 'Position', [20, 730, 200, 22], 'Text', 'Enter waypoints (degrees) [e.g., 0, 30, 60, 90]:');
edit1 = uieditfield(hFig, 'text', 'Position', [220, 730, 200, 22], 'Value', '0, 30, 60, 90');

lbl2 = uilabel(hFig, 'Position', [20, 690, 200, 22], 'Text', 'Enter total time (seconds):');
edit2 = uieditfield(hFig, 'numeric', 'Position', [220, 690, 100, 22], 'Value', 10);

% Create a button to generate velocity input fields
btn1 = uibutton(hFig, 'push', 'Position', [20, 650, 200, 22], 'Text', 'Set Number of Waypoints', ...
    'ButtonPushedFcn', @(btn1, event) createVelocityInputs(edit1, hFig));

% Create a button to generate the plot
btn2 = uibutton(hFig, 'push', 'Position', [20, 610, 100, 22], 'Text', 'Generate Plot', ...
    'ButtonPushedFcn', @(btn2, event) generatePlot(edit1, edit2, ax));

% Function to create velocity input fields based on number of waypoints
function createVelocityInputs(edit1, hFig)
    waypoints = str2num(edit1.Value); % Convert waypoints from string to numeric array
    num_segments = length(waypoints) - 1; % Number of segments

    % Remove previous velocity input fields if they exist
    delete(findobj(hFig, 'Tag', 'velocityInput'));

    % Create input fields for initial and final velocities for each segment
    for i = 1:num_segments
        lbl_initial = uilabel(hFig, 'Position', [20, 580 - (i-1)*40, 200, 22], ...
            'Text', ['Segment ', num2str(i), ' Initial Velocity (deg/s):'], 'Tag', 'velocityInput');
        uieditfield(hFig, 'numeric', 'Position', [220, 580 - (i-1)*40, 100, 22], 'Value', 0, 'Tag', 'velocityInput', ...
            'UserData', ['initial_', num2str(i)]);

        lbl_final = uilabel(hFig, 'Position', [20, 560 - (i-1)*40, 200, 22], ...
            'Text', ['Segment ', num2str(i), ' Final Velocity (deg/s):'], 'Tag', 'velocityInput');
        uieditfield(hFig, 'numeric', 'Position', [220, 560 - (i-1)*40, 100, 22], 'Value', 0, 'Tag', 'velocityInput', ...
            'UserData', ['final_', num2str(i)]);
    end
end

% Function to generate plot based on user input
function generatePlot(edit1, edit2, ax)
    % Parse user input
    waypoints = str2num(edit1.Value); % Convert waypoints from string to numeric array
    num_waypoints = length(waypoints); % Number of waypoints
    T_total = edit2.Value; % Total time in seconds
    T_segment = T_total / (num_waypoints - 1); % Time per segment
    t = linspace(0, T_total, 1000); % Time vector divided into 1000 segments for smooth plotting

    % Find velocity input fields
    velocity_inputs = findobj(ax.Parent, 'Tag', 'velocityInput');
    initial_velocities = zeros(1, num_waypoints-1);
    final_velocities = zeros(1, num_waypoints-1);

    % Extract initial and final velocities for each segment
    for i = 1:length(velocity_inputs)
        userData = string(velocity_inputs(i).UserData);
        segment_idx = str2double(regexp(userData, '\d+', 'match'));
        if contains(userData, 'initial')
            initial_velocities(segment_idx) = velocity_inputs(i).Value;
        elseif contains(userData, 'final')
            final_velocities(segment_idx) = velocity_inputs(i).Value;
        end
    end

    % Initialize position, velocity, and acceleration arrays
    position = zeros(1, length(t));
    velocity = zeros(1, length(t));
    acceleration = zeros(1, length(t));

    % Loop through each segment and calculate cubic polynomial coefficients
    for i = 1:num_waypoints-1
        % Boundary conditions for each segment
        theta_0 = waypoints(i);
        theta_f = waypoints(i+1);
        theta_dot_0 = initial_velocities(i);
        theta_dot_f = final_velocities(i);

        % Time vector for the current segment
        t_start = (i-1) * T_segment;
        t_end = i * T_segment;
        t_segment = linspace(t_start, t_end, sum(t >= t_start & t <= t_end));

        % Calculate cubic polynomial coefficients based on boundary conditions
        % The cubic polynomial form: theta(t) = a0 + a1*t + a2*t^2 + a3*t^3
        A = [1, 0, 0, 0; % Position at t = 0
             0, 1, 0, 0; % Velocity at t = 0
             1, T_segment, T_segment^2, T_segment^3; % Position at t = T_segment
             0, 1, 2*T_segment, 3*T_segment^2]; % Velocity at t = T_segment

        % Boundary conditions vector
        b = [theta_0; theta_dot_0; theta_f; theta_dot_f];

        % Solve for polynomial coefficients
        coeffs = A\b;

        % Calculate position, velocity, and acceleration for the current segment
        pos_segment = coeffs(1) + coeffs(2)*(t_segment - t_start) + coeffs(3)*(t_segment - t_start).^2 + coeffs(4)*(t_segment - t_start).^3;
        vel_segment = coeffs(2) + 2*coeffs(3)*(t_segment - t_start) + 3*coeffs(4)*(t_segment - t_start).^2;
        acc_segment = 2*coeffs(3) + 6*coeffs(4)*(t_segment - t_start);

        % Store the calculated values in the overall position, velocity, and acceleration arrays
        idx = (t >= t_start) & (t <= t_end);
        position(idx) = pos_segment;
        velocity(idx) = vel_segment;
        acceleration(idx) = acc_segment;
    end

    % Clear the previous plot if it exists
    cla(ax);

    % Plot position, velocity, and acceleration in a single chart
    plot(ax, t, position, 'b-', 'LineWidth', 2); % Plot position (blue line)
    hold(ax, 'on');
    plot(ax, t, velocity, 'r--', 'LineWidth', 2); % Plot velocity (red dashed line)
    plot(ax, t, acceleration, 'g-.', 'LineWidth', 2); % Plot acceleration (green dash-dot line)
    hold(ax, 'off');

    % Add labels, title, and legend
    xlabel(ax, 'Time (s)');
    ylabel(ax, 'Magnitude');
    title(ax, 'Cubic Polynomial Trajectory: Position, Velocity, and Acceleration for Multiple Waypoints');
    grid(ax, 'on');
    legend(ax, 'Position (deg)', 'Velocity (deg/s)', 'Acceleration (deg/s^2)');
end

% Explanation of the plot:
% The blue line represents the position of the trajectory over time, starting from the user-defined waypoints.
% The red dashed line represents the velocity, which starts and ends based on the boundary conditions, ensuring a smooth transition.
% The green dash-dot line represents the acceleration, which changes smoothly to accommodate the cubic trajectory.
% The plot shows how position, velocity, and acceleration evolve over time, ensuring smooth motion without abrupt changes.