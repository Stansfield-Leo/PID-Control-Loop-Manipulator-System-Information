% Define the symbolic variables
syms theta1 theta2 theta3 real
syms d a2 a3 a4 real

% Define the elements of the Jacobian matrix J11
J11 = [d*cos(theta1)-a2*sin(theta1) - a3*sin(theta1)*cos(theta2) + a4*sin(theta1)*sin(theta2)*sin(theta3) - a4*sin(theta1)*cos(theta2)*cos(theta3), ...
      -a3*cos(theta1)*sin(theta2) - a4*cos(theta1)*cos(theta2)*sin(theta3) - a4*cos(theta1)*sin(theta2)*cos(theta3), ...
      -a4*cos(theta1)*cos(theta2)*sin(theta3) - a4*cos(theta1)*sin(theta2)*cos(theta3);
       a2*cos(theta1) + d*sin(theta1) + a3*cos(theta1)*cos(theta2) - a4*cos(theta1)*sin(theta2)*sin(theta3) + a4*cos(theta1)*cos(theta2)*cos(theta3), ...
      -a3*sin(theta1)*sin(theta2) - a4*sin(theta1)*cos(theta2)*sin(theta3) - a4*sin(theta1)*sin(theta2)*cos(theta3), ...
      -a4*sin(theta1)*cos(theta2)*sin(theta3) - a4*sin(theta1)*sin(theta2)*cos(theta3);
       0, ...
      -a4*cos(theta2 + theta3) - a3*cos(theta2), ...
      -a4*cos(theta2 + theta3)];

% Calculate the determinant of J11
det_J11 = simplify(det(J11));

% Display the result
disp('The determinant of the Jacobian matrix J11 is:');
disp(det_J11);
