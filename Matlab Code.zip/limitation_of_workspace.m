% define leanth of the links (unit：mm)
AB = 136.3;
BC = 10;
CD = 32;
DE = 26.8;
EL = 22.7;

% define rotation limit of motors (degree)
thetaA_limit = [0, 180]; % rotation limit of motor A
thetaC_limit = [0, 114]; % rotation limit of motor B
thetaD_limit = [0, 88];  % rotation limit of motor C
thetaE_limit = [0, 2];   % rotation limit of motor D

% convert degrees into radius
thetaA_rad = deg2rad(thetaA_limit);
thetaC_rad = deg2rad(thetaC_limit);
thetaD_rad = deg2rad(thetaD_limit);
thetaE_rad = deg2rad(thetaE_limit);

% initialize the array of end point positions
end_effector_x = [];
end_effector_y = [];
end_effector_z = [];

% list all possible motor angle combinations
for thetaA = linspace(thetaA_rad(1), thetaA_rad(2), 20)
    for thetaC = linspace(thetaC_rad(1), thetaC_rad(2), 20)
        for thetaD = linspace(thetaD_rad(1), thetaD_rad(2), 20)
            for thetaE = linspace(thetaE_rad(1), thetaE_rad(2), 5)
                % forward kinematics calculation of end point position
                [L, ~, ~, ~, ~] = forwardKinematics(thetaA, thetaC, thetaD, thetaE);
                
                % save the coordinates of the end point
                end_effector_x = [end_effector_x; L(1)];
                end_effector_y = [end_effector_y; L(2)];
                end_effector_z = [end_effector_z; L(3)];
            end
        end
    end
end

% calculate the end point coordinate range
x_min = min(end_effector_x);
x_max = max(end_effector_x);
y_min = min(end_effector_y);
y_max = max(end_effector_y);
z_min = min(end_effector_z);
z_max = max(end_effector_z);

% display reachable space
disp(['X axis limitation: ', num2str(x_min), ' to ', num2str(x_max)]);
disp(['Y axis limitation: ', num2str(y_min), ' to ', num2str(y_max)]);
disp(['Z axis limitation:', num2str(z_min), ' to ', num2str(z_max)]);

% draw the workspace
figure;
plot3(end_effector_x, end_effector_y, end_effector_z, 'b.');
xlabel('X (mm)');
ylabel('Y (mm)');
zlabel('Z (mm)');
title('workspace of the manipulator');
grid on;
axis equal;

% conduct forward kinematic calculation
function [L, B, C, D, E] = forwardKinematics(thetaA, thetaC, thetaD, thetaE)
    % leanth of the links
    AB = 136.3;
    BC = 10;
    CD = 32;
    DE = 26.8;
    EL = 22.7;

    % rotation matrix
    RzA = [cos(thetaA), -sin(thetaA), 0; sin(thetaA), cos(thetaA), 0; 0, 0, 1];
    RyC = [cos(thetaC), 0, sin(thetaC); 0, 1, 0; -sin(thetaC), 0, cos(thetaC)];
    RyD = [cos(thetaD), 0, sin(thetaD); 0, 1, 0; -sin(thetaD), 0, cos(thetaD)];
    RyE = [cos(thetaE), 0, sin(thetaE); 0, 1, 0; -sin(thetaE), 0, cos(thetaE)];

    % joint position calculation
    B = RzA * [0; 0; AB]; % position of point B
    C = B + RzA * [0; BC; 0]; % position of point C
    D = C + RzA * RyC * [0; 0; CD]; % position of point D
    E = D + RzA * RyC * RyD * [0; 0; DE]; % position of point E
    L = E + RzA * RyC * RyD * RyE * [0; 0; EL]; % position of point L
end
