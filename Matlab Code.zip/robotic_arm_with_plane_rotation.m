function robotic_arm_with_surface_and_trajectory()
    % build the main window
    fig = figure('Name', 'Workspace of the Manipulator', 'NumberTitle', 'off', 'Position', [100, 100, 800, 600]);

    % initialize angular value
    thetaA = 0;  % initial angle of motor A
    thetaC = 0;  % initial angle of motor C
    thetaD = 0;  % initial angle of motor D
    thetaE = 0;  % initial angle of motor E

    % initialize the coordinates of the L point trajectory
    L_trajectory_x = [];
    L_trajectory_y = [];
    L_trajectory_z = [];

    % create teh 3D graphics region
    ax = axes('Parent', fig, 'Position', [0.3, 0.1, 0.65, 0.8]);
    hold(ax, 'on');
    grid(ax, 'on');
    axis(ax, 'equal');
    xlabel(ax, 'X (mm)');
    ylabel(ax, 'Y (mm)');
    zlabel(ax, 'Z (mm)');
    title(ax, 'Workspace of the Manipulator');
    view(ax, [135 30]);  % 固定视角

    % create the slider and label for motor A
    uicontrol('Parent', fig, 'Style', 'text', 'String', '电机A (°)', 'Position', [20, 500, 100, 20]);
    sliderA = uicontrol('Parent', fig, 'Style', 'slider', 'Min', 0, 'Max', 180, 'Value', thetaA, ...
                        'Position', [20, 470, 100, 20], 'Callback', @updatePlot);
                    
    % create the slider and label for motor C
    uicontrol('Parent', fig, 'Style', 'text', 'String', '电机C (°)', 'Position', [20, 400, 100, 20]);
    sliderC = uicontrol('Parent', fig, 'Style', 'slider', 'Min', 0, 'Max', 114, 'Value', thetaC, ...
                        'Position', [20, 370, 100, 20], 'Callback', @updatePlot);

    % create the slider and label for motor D
    uicontrol('Parent', fig, 'Style', 'text', 'String', '电机D (°)', 'Position', [20, 300, 100, 20]);
    sliderD = uicontrol('Parent', fig, 'Style', 'slider', 'Min', 0, 'Max', 88, 'Value', thetaD, ...
                        'Position', [20, 270, 100, 20], 'Callback', @updatePlot);

    % create the slider and label for motor E
    uicontrol('Parent', fig, 'Style', 'text', 'String', '电机E (°)', 'Position', [20, 200, 100, 20]);
    sliderE = uicontrol('Parent', fig, 'Style', 'slider', 'Min', 0, 'Max', 2, 'Value', thetaE, ...
                        'Position', [20, 170, 100, 20], 'Callback', @updatePlot);

    % call the forward kinematics algorithm and update the image
    updatePlot();

    function updatePlot(~, ~)
        % get the current slider angle value
        thetaA = get(sliderA, 'Value');
        thetaC = get(sliderC, 'Value');
        thetaD = get(sliderD, 'Value');
        thetaE = get(sliderE, 'Value');

        % perform forward kinematics calculations
        [X, Y, Z, L_pos, B_pos] = forwardKinematics(thetaA, thetaC, thetaD, thetaE);

        % clear the graphic and redraw it
        cla(ax);
        plot3(ax, X, Y, Z, 'ko-', 'LineWidth', 2, 'MarkerSize', 8);
        xlabel(ax, 'X (mm)');
        ylabel(ax, 'Y (mm)');
        zlabel(ax, 'Z (mm)');
        title(ax, 'Workspace of the Manipulator');
        axis(ax, 'equal');
        grid(ax, 'on');

        % update the trajectory of point L
        L_trajectory_x = [L_trajectory_x; L_pos(1)];
        L_trajectory_y = [L_trajectory_y; L_pos(2)];
        L_trajectory_z = [L_trajectory_z; L_pos(3)];

        % draw the trajectory of point L
        plot3(ax, L_trajectory_x, L_trajectory_y, L_trajectory_z, 'b-', 'LineWidth', 1.5);
        plot3(ax, L_pos(1), L_pos(2), L_pos(3), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');

        % draw the plane formed between point L and point B
        plotPlaneBetweenBAndL(B_pos, L_pos);

        % draw the rotation of motor A driving the rotation of the plane
        rotatePlaneWithA(thetaA);
    end

    function [X, Y, Z, L_pos, B_pos] = forwardKinematics(thetaA, thetaC, thetaD, thetaE)
        % robotic arm link length definition
        AB = 136.3; % AB
        BC = 10;    % BC
        CD = 32;    % CD
        DE = 26.8;  % DE
        EL = 22.7;  % EL
        
        % convert degrees to radians
        thetaA = deg2rad(thetaA);
        thetaC = deg2rad(thetaC);
        thetaD = deg2rad(thetaD);
        thetaE = deg2rad(thetaE);

        % motor A rotates to drive the entire system
        RzA = [cos(thetaA), -sin(thetaA), 0; 
               sin(thetaA), cos(thetaA), 0; 
               0, 0, 1];

        % motor C drives CD, DE, EL to rotate, and the rotating plane is always perpendicular to the XY plane
        RyC = [cos(thetaC), 0, sin(thetaC); 
               0, 1, 0;
               -sin(thetaC), 0, cos(thetaC)];

        % motor D drives DE and EL to rotate
        RyD = [cos(thetaD), 0, sin(thetaD); 
               0, 1, 0;
               -sin(thetaD), 0, cos(thetaD)];

        % motor E drives EL to rotate
        RyE = [cos(thetaE), 0, sin(thetaE); 
               0, 1, 0;
               -sin(thetaE), 0, cos(thetaE)];

        % calculate the position of each point
        B = RzA * [0; 0; AB];  % point B position
        C = B + RzA * [0; BC; 0];  % Point C position
        D = C + RzA * RyC * [0; 0; CD];  % Point D position
        E = D + RzA * RyC * RyD * [0; 0; DE];  % Point E position
        L = E + RzA * RyC * RyD * RyE * [0; 0; EL];  % Point L position

        % connect the points into an array for plotting
        X = [0, B(1), C(1), D(1), E(1), L(1)];
        Y = [0, B(2), C(2), D(2), E(2), L(2)];
        Z = [0, B(3), C(3), D(3), E(3), L(3)];

        % return the coordinates of point L and point B
        L_pos = L;
        B_pos = B;
    end

    function plotPlaneBetweenBAndL(B_pos, L_pos)
        % draw the rotation plane formed by points B and L
        mid_point = (B_pos + L_pos) / 2;  % midpoint
        normal_vector = cross(B_pos - [0; 0; 0], L_pos - B_pos);  % normal vector
        normal_vector = normal_vector / norm(normal_vector);  % normalization
        d = -dot(normal_vector, mid_point);  % d value of the plane equation

        % generate rotation plane
        [planeX, planeY] = meshgrid(linspace(-150, 150, 20), linspace(-150, 150, 20));
        planeZ = (-normal_vector(1) * planeX - normal_vector(2) * planeY - d) / normal_vector(3);

        % create the plane
        surf(planeX, planeY, planeZ, 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'FaceColor', 'cyan');
    end

    function rotatePlaneWithA(thetaA)
        % draw the rotation plane trajectory driven by motor A
        for angle = 0:5:thetaA
            RzA = [cos(deg2rad(angle)), -sin(deg2rad(angle)), 0; 
                   sin(deg2rad(angle)), cos(deg2rad(angle)), 0; 
                   0, 0, 1];
            rotated_points = RzA * [L_trajectory_x'; L_trajectory_y'; L_trajectory_z'];
            plot3(rotated_points(1, :), rotated_points(2, :), rotated_points(3, :), 'm--');
        end
    end
end
