syms theta1 theta2 theta3 d a2 a3 a4

% Define the Jacobian matrix
J_q = [
    d*cos(theta1) - a2*sin(theta1) - a3*sin(theta1)*cos(theta2) + a4*sin(theta1)*sin(theta2)*sin(theta3) - a4*sin(theta1)*cos(theta2)*cos(theta3), ...
    -a3*cos(theta1)*sin(theta2) - a4*cos(theta1)*cos(theta2)*sin(theta3) - a4*cos(theta1)*sin(theta2)*cos(theta3), ...
    -a4*cos(theta1)*cos(theta2)*sin(theta3) - a4*cos(theta1)*sin(theta2)*cos(theta3), 0;
    a2*cos(theta1) + d*sin(theta1) + a3*cos(theta1)*cos(theta2) - a4*cos(theta1)*sin(theta2)*sin(theta3) + a4*cos(theta1)*cos(theta2)*cos(theta3), ...
    -a3*sin(theta1)*sin(theta2) - a4*sin(theta1)*cos(theta2)*sin(theta3) - a4*sin(theta1)*sin(theta2)*cos(theta3), ...
    -a4*sin(theta1)*cos(theta2)*sin(theta3) - a4*sin(theta1)*sin(theta2)*cos(theta3), 0;
    0, ...
    -a4*cos(theta2 + theta3) - a3*cos(theta2), ...
    -a4*cos(theta2 + theta3), 0;
    -cos(theta1), 0, 0, 0;
    -sin(theta1), 0, 0, 0;
    0, 0, 0, 0
];

% Extract the linear velocity part J_v
J_v = J_q(1:3, 1:3); % Take only the first 3 rows and first 3 columns

% Calculate the determinant of J_v
det_Jv = simplify(det(J_v));

% Calculate the rank of J_v
rank_Jv = rank(J_v);

% Display the results
disp('Jacobian (J_v) determinant:');
disp(det_Jv);
disp('Jacobian (J_v) rank:');
disp(rank_Jv);
