% Define symbolic variables for angles and distances
syms theta1 theta2 theta3 theta4 d1 d2 d3 d4 alpha0 alpha1 alpha2 alpha3 real
% First transformation matrix (T1)
T1 = [cos(theta1), -sin(theta1), 0, 136.3;
sin(theta1), cos(theta1), 0, 0;
0, 0, 1, 0;
0, 0, 0, 1]
T2 = [cos(theta2),  0, -sin(theta2) , 32;
sin(theta2), 0, cos(theta2), 0;
0, -1, 0, -10;
0, 0, 0, 1];
% Third transformation matrix (T3)
T3 = [cos(theta3), -sin(theta3), 0, 26.8;
sin(theta3), cos(theta3), 0, 0;
0, 0, 1, 0;
0, 0, 0, 1];
% Fourth transformation matrix (T4)
T4 = [cos(theta4), -sin(theta4), 0, 22.7;
sin(theta4), cos(theta4), 0, 0;
0, 0, 1, 0;
0, 0, 0, 1];
% Multiply all the transformation matrices and simplify each result
T02 = simplify(T1 * T2);
T03 = simplify(T1 * T2 * T3);
T_total = simplify(T1 * T2 * T3 * T4);
T021 = (T1*T2);
T031 = (T1*T2*T3);
T_total1 = (T1*T2*T3*T4);
% Display the simplified results
disp(T02);
disp(T03);
disp(T_total);
disp(T021);
disp(T031);
disp(T_total1);