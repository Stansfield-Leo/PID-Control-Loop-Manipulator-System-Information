% MATLAB Code for Curve-Line Trajectory Planning with Parabolic Blends and Via Points
% This script generates a trajectory consisting of two parabolic segments at the start and end,
% with a linear segment in the middle to ensure a smooth transition between acceleration and deceleration.
% It supports multiple via points for path motion with independent velocities and times for each segment.

% Clear workspace and close all figures
clear; clc; close all;

% Create a UI figure for user input
hFig = uifigure('Name', 'Curve-Line Trajectory Planner with Via Points', 'Position', [100, 100, 600, 800]);

% Create input fields for trajectory parameters
lbl1 = uilabel(hFig, 'Position', [20, 720, 200, 22], 'Text', 'Enter waypoints (degrees) [e.g., 0, 30, 60, 90]:');
edit1 = uieditfield(hFig, 'text', 'Position', [220, 720, 200, 22], 'Value', '0, 30, 60, 90');

% Create inputs for segment times and velocities
waypoints = str2num(edit1.Value); %#ok<ST2NM>
n_segments = length(waypoints) - 1;

if n_segments < 1
    error('Please enter at least two waypoints.');
end

segment_times = cell(1, n_segments);
segment_velocities = cell(1, n_segments);

for i = 1:n_segments
    lbl_time = uilabel(hFig, 'Position', [20, 680 - (i - 1) * 60, 200, 22], 'Text', sprintf('Enter time for segment %d (seconds):', i));
    segment_times{i} = uieditfield(hFig, 'numeric', 'Position', [220, 680 - (i - 1) * 60, 100, 22], 'Value', 2);
    
    lbl_velocity = uilabel(hFig, 'Position', [20, 650 - (i - 1) * 60, 200, 22], 'Text', sprintf('Enter max velocity for segment %d (deg/s):', i));
    segment_velocities{i} = uieditfield(hFig, 'numeric', 'Position', [220, 650 - (i - 1) * 60, 100, 22], 'Value', 15);
end

% Create a button to generate the plot
btn = uibutton(hFig, 'push', 'Position', [20, 650 - n_segments * 60, 100, 22], 'Text', 'Generate Plot', ...
    'ButtonPushedFcn', @(btn, event) generatePlot(edit1.Value, segment_times, segment_velocities));

% Function to generate the plot
function generatePlot(waypoints_str, segment_times, segment_velocities)
    num_points = 1000; % Number of points for plotting
    
    % Parse waypoints input
    waypoints = str2num(waypoints_str); %#ok<ST2NM>
    n_segments = length(waypoints) - 1;
    
    if n_segments < 1
        error('Please enter at least two waypoints.');
    end
    
    % Time vector for the entire trajectory
    t_total = []; % Initialize time vector for the whole trajectory
    position_total = [];
    velocity_total = [];
    acceleration_total = [];
    
    % Loop through each segment and generate individual trajectories
    for seg = 1:n_segments
        q0 = waypoints(seg);
        qf = waypoints(seg + 1);
        delta_q = qf - q0;
        
        % Get segment-specific time and velocity
        T_segment = segment_times{seg}.Value;
        v_max = abs(segment_velocities{seg}.Value); % Use absolute value for maximum velocity to avoid negative velocity issues
        direction = sign(delta_q); % Determine direction of movement based on delta_q
        
        % Calculate blend time to ensure smooth trajectory
        T_blend = min(T_segment / 4, abs(delta_q) / (2 * v_max));
        T_linear = T_segment - 2 * T_blend;
        if T_linear < 0
            T_blend = T_segment / 2;
            T_linear = 0;
        end
        
        a_blend = v_max / T_blend; % Acceleration during blend phases
        
        % Time vector for the current segment
        t_segment = linspace(0, T_segment, num_points / n_segments);
        position = zeros(1, length(t_segment));
        velocity = zeros(1, length(t_segment));
        acceleration = zeros(1, length(t_segment));
        
        % Define phases of the trajectory for the current segment
        for i = 1:length(t_segment)
            t_current = t_segment(i);
            
            % Parabolic blend at the start (0 <= t <= T_blend)
            if t_current <= T_blend
                position(i) = q0 + 0.5 * direction * a_blend * t_current^2;
                velocity(i) = direction * a_blend * t_current;
                acceleration(i) = direction * a_blend;
            % Linear segment (T_blend < t <= T_blend + T_linear)
            elseif t_current <= T_blend + T_linear
                position(i) = q0 + 0.5 * v_max * T_blend * direction + v_max * (t_current - T_blend) * direction;
                velocity(i) = v_max * direction;
                acceleration(i) = 0;
            % Parabolic blend at the end (T_blend + T_linear < t <= T_segment)
            else
                delta_t = t_current - (T_segment - T_blend);
                position(i) = q0 + 0.5 * v_max * T_blend * direction + v_max * (t_current - T_blend) * direction - 0.5 * direction * a_blend * delta_t^2;
                velocity(i) = v_max * direction - a_blend * delta_t * direction;
                acceleration(i) = -a_blend * direction;
            end
        end
        
        % Append the results to the total vectors
        t_total = [t_total, t_segment + (seg - 1) * T_segment]; %#ok<AGROW>
        position_total = [position_total, position]; %#ok<AGROW>
        velocity_total = [velocity_total, velocity]; %#ok<AGROW>
        acceleration_total = [acceleration_total, acceleration]; %#ok<AGROW>
    end
    
    % Plotting the results
    figure;
    subplot(3, 1, 1);
    plot(t_total, position_total, 'b', 'LineWidth', 2);
    ylabel('Position (deg)');
    title('Curve-Line Trajectory with Via Points: Position, Velocity, and Acceleration');
    grid on;
    
    subplot(3, 1, 2);
    plot(t_total, velocity_total, 'r', 'LineWidth', 2);
    ylabel('Velocity (deg/s)');
    grid on;
    
    subplot(3, 1, 3);
    plot(t_total, acceleration_total, 'g', 'LineWidth', 2);
    ylabel('Acceleration (deg/s^2)');
    xlabel('Time (s)');
    grid on;
end

% Explanation:don't touch this one
% - The trajectory starts with a parabolic blend, which provides smooth acceleration.
% - Then, it transitions into a linear segment with constant velocity.
% - Finally, it ends with another parabolic blend to decelerate smoothly to the final position.
% - The blend time is recalculated to ensure the target position is reached smoothly without overshooting.
% - The code supports multiple via points, generating individual trajectories for each segment and combining them for complex path motion.
% - Each segment has its own input for maximum velocity and time, allowing for greater control over the trajectory.
% - Negative velocities are properly handled by using the direction of movement and ensuring positive acceleration values are applied appropriately.
% - The blend time is adjusted to maintain a constant velocity phase, allowing for uniform motion during the linear segment.