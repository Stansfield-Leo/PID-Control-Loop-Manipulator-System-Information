% Load symbolic package
syms theta1 theta2 theta3 theta4 real
syms dot_theta1 dot_theta2 dot_theta3 dot_theta4 real
syms ddot_theta1 ddot_theta2 ddot_theta3 ddot_theta4 real
syms m1 m2 m3 m4 d1 a1 a2 a3 a4 g real

% Define the kinetic energy expressions for each link
T1 = 0.5 * m1 * d1^2 * dot_theta1^2;
T2 = 0.5 * m2 * (a2^2 * dot_theta2^2);
T3 = 0.5 * m3 * ((a2^2 + a3^2 + 2 * a2 * a3 * cos(theta3)) * (dot_theta2 + dot_theta3)^2);
T4 = 0.5 * m4 * ((a2^2 + a3^2 + a4^2 + 2 * a2 * a3 * cos(theta3) + 2 * a2 * a4 * cos(theta3 + theta4) + 2 * a3 * a4 * cos(theta4)) * (dot_theta2 + dot_theta3 + dot_theta4)^2);

% Define the potential energy expressions for each link
V = -m1 * g * a1 - m2 * g * (a2 * cos(theta2) + a1) - m3 * g * (a2 * cos(theta2) + a3 * cos(theta2 + theta3) + a1) - m4 * g * (a2 * cos(theta2) + a3 * cos(theta2 + theta3) + a4 * cos(theta2 + theta3 + theta4) + a1);

% Lagrangian
L = T1 + T2 + T3 + T4 - V;

% Compute the torques
tau1 = simplify(diff(diff(L, dot_theta1), 't') - diff(L, theta1));
tau2 = simplify(diff(diff(L, dot_theta2), 't') - diff(L, theta2));
tau3 = simplify(diff(diff(L, dot_theta3), 't') - diff(L, theta3));
tau4 = simplify(diff(diff(L, dot_theta4), 't') - diff(L, theta4));

% Display the results
disp('Tau1 = ');
pretty(tau1)

disp('Tau2 = ');
pretty(tau2)

disp('Tau3 = ');
pretty(tau3)

disp('Tau4 = ');
pretty(tau4)
