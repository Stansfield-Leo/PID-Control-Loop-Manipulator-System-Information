% 定义符号变量
syms theta1 theta2 theta3 theta4 a1 a2 a3 d1 d2 d3 d4 real
% 定义变换矩阵的旋转和位置部分
R = [cos(theta1 + theta2)*cos(theta3 + theta4), -cos(theta1 + theta2)*sin(theta3 + theta4), -sin(theta1 + theta2);
cos(theta3 + theta4)*sin(theta1 + theta2), -sin(theta1)*sin(theta2 + theta3 + theta4), cos(theta1 + theta2);
-sin(theta3 + theta4), -cos(theta3 + theta4), 0];
P = [(134*cos(theta1 + theta2))/5 + 32*cos(theta1) + (227*cos(theta1 + theta2)*cos(theta3))/10 + 1363/10;
(134*sin(theta1 + theta2))/5 + 32*sin(theta1) + (227*sin(theta1 + theta2)*cos(theta3))/10;
 - (227*sin(theta3))/10 - 10];
% 完整的齐次变换矩阵
T = [R, P; 0, 0, 0, 1];
% 对 theta1 求偏导
J_theta1 = jacobian(T(1:3,4), theta1);
% 对 theta1 求偏导
J_theta2 = jacobian(T(1:3,4), theta2);
% 对 theta3 求偏导
J_theta3 = jacobian(T(1:3,4), theta3);
% 对 theta4 求偏导
J_theta4 = jacobian(T(1:3,4), theta4);
% 显示结果
disp('对 theta1 求偏导:');
disp(J_theta1);
disp('对 theta2 求偏导:');
disp(J_theta2);
disp('对 theta3 求偏导:');
disp(J_theta3);
disp('对 theta4 求偏导:');
disp(J_theta4);