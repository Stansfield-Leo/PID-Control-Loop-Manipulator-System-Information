% MATLAB code to generate position, velocity, and acceleration values within a bounded range
% The generated trajectory uses a cubic polynomial, and the script plots position, velocity,
% and acceleration curves on the same chart for visualization.

% Clear workspace and close all figures
clear; clc; close all;

% Create a UI figure for inputs and plot
hFig = uifigure('Name', 'Trajectory Planner', 'Position', [100, 100, 600, 600]);

% Create input fields for boundary conditions
lbl1 = uilabel(hFig, 'Position', [20, 530, 200, 22], 'Text', 'Enter initial position (degrees):');
edit1 = uieditfield(hFig, 'numeric', 'Position', [220, 530, 100, 22], 'Value', 0);

lbl2 = uilabel(hFig, 'Position', [20, 490, 200, 22], 'Text', 'Enter final position (degrees):');
edit2 = uieditfield(hFig, 'numeric', 'Position', [220, 490, 100, 22], 'Value', 90);

lbl3 = uilabel(hFig, 'Position', [20, 450, 200, 22], 'Text', 'Enter initial velocity (deg/s):');
edit3 = uieditfield(hFig, 'numeric', 'Position', [220, 450, 100, 22], 'Value', 0);

lbl4 = uilabel(hFig, 'Position', [20, 410, 200, 22], 'Text', 'Enter final velocity (deg/s):');
edit4 = uieditfield(hFig, 'numeric', 'Position', [220, 410, 100, 22], 'Value', 0);

% Create a button to generate the plot
btn = uibutton(hFig, 'push', 'Position', [20, 360, 100, 22], 'Text', 'Generate Plot', 'ButtonPushedFcn', @(btn,event) generatePlot(edit1, edit2, edit3, edit4));

% Function to generate plot based on user input
function generatePlot(edit1, edit2, edit3, edit4)
    % Parse user input
    theta_0 = edit1.Value;    % Initial position (degrees)
    theta_f = edit2.Value;    % Final position (degrees)
    theta_dot_0 = edit3.Value; % Initial velocity (deg/s)
    theta_dot_f = edit4.Value; % Final velocity (deg/s)

    % Time settings
    T = 5; % Total time in seconds
    t = linspace(0, T, 200); % Time vector divided into 200 segments for smooth plotting

    % Calculate cubic polynomial coefficients based on boundary conditions
    % The cubic polynomial form: theta(t) = a0 + a1*t + a2*t^2 + a3*t^3
    A = [1, 0, 0, 0; % Position at t = 0
         0, 1, 0, 0; % Velocity at t = 0
         1, T, T^2, T^3; % Position at t = T
         0, 1, 2*T, 3*T^2]; % Velocity at t = T
     
    % Boundary conditions vector
    b = [theta_0; theta_dot_0; theta_f; theta_dot_f];

    % Solve for polynomial coefficients
    coeffs = A\b;

    % Calculate position, velocity, and acceleration
    position = coeffs(1) + coeffs(2)*t + coeffs(3)*t.^2 + coeffs(4)*t.^3;
    velocity = coeffs(2) + 2*coeffs(3)*t + 3*coeffs(4)*t.^2;
    acceleration = 2*coeffs(3) + 6*coeffs(4)*t;

    % Ensure initial acceleration is zero
    acceleration(1) = 0;

    % Create a UI axis for plotting
    ax = uiaxes('Parent', edit1.Parent, 'Position', [20, 20, 550, 300]);

    % Plot position, velocity, and acceleration in a single chart
    plot(ax, t, position, 'b-', 'LineWidth', 2); % Plot position (blue line)
    hold(ax, 'on');
    plot(ax, t, velocity, 'r--', 'LineWidth', 2); % Plot velocity (red dashed line)
    plot(ax, t, acceleration, 'g-.', 'LineWidth', 2); % Plot acceleration (green dash-dot line)
    hold(ax, 'off');

    % Add labels, title, and legend
    xlabel(ax, 'Time (s)');
    ylabel(ax, 'Magnitude');
    title(ax, 'Cubic Polynomial Trajectory: Position, Velocity, and Acceleration');
    grid(ax, 'on');
    legend(ax, 'Position (deg)', 'Velocity (deg/s)', 'Acceleration (deg/s^2)');
end

% Explanation of the plot:
% The blue line represents the position of the trajectory over time, starting from the user-defined initial position and ending at the final position.
% The red dashed line represents the velocity, which starts and ends based on user input, ensuring a smooth transition.
% The green dash-dot line represents the acceleration, which starts at zero and changes smoothly to accommodate the cubic trajectory.
% The plot shows how position, velocity, and acceleration evolve over time, ensuring smooth motion without abrupt changes.